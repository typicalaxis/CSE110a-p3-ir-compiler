
void test0 (int &a) {
  a = a + 1;
}
